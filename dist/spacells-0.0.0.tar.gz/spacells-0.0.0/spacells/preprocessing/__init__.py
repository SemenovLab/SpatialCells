from ._setGate import setGate
from ._setGates import setGates